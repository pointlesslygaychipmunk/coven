// src/turnEngine.ts
// Handles advancing the game state by one lunar phase (and possibly season/year)
// Manages weather changes, plant growth, and time progression

// Use package name import
import { GameState, Season, WeatherFate, MoonPhase, Plant, GardenSlot, GameTime, JournalEntry, Player } from "coven-shared";
// Import specific Ingredient type from ingredients.ts
import { calculateGrowthModifier, getIngredientData, getGrowthStageDescription } from "./ingredients.js";

// Ordered arrays for moon phases and seasons - Exported for use elsewhere
export const MoonPhases: MoonPhase[] = [ "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous", "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent" ];
export const Seasons: Season[] = ["Spring", "Summer", "Fall", "Winter"];
const PHASES_PER_SEASON = MoonPhases.length * 3;

function nextSeason(current: Season): Season { const idx = Seasons.indexOf(current); return Seasons[(idx + 1) % Seasons.length]; }

// Determine weather with some correlation to previous weather and season
function determineWeather(time: GameTime): WeatherFate {
    // Added explicit type for 'time' parameter
    const previousWeather = time.previousWeatherFate; const season = time.season;
    const weatherChances: Record<Season, Partial<Record<WeatherFate, number>>> = { "Spring": { "normal": 0.4, "rainy": 0.4, "dry": 0.05, "foggy": 0.1, "windy": 0.05 }, "Summer": { "normal": 0.3, "rainy": 0.15, "dry": 0.4, "windy": 0.05, "stormy": 0.1 }, "Fall": { "normal": 0.3, "rainy": 0.25, "dry": 0.1, "foggy": 0.2, "windy": 0.15 }, "Winter": { "normal": 0.5, "rainy": 0.1, "dry": 0.1, "foggy": 0.2, "windy": 0.1 } };
    const chances = weatherChances[season]; let currentTotal = 0; for(const k in chances) currentTotal += chances[k as WeatherFate] || 0;
    if(Math.abs(currentTotal - 1.0) > 0.01) { const factor = 1.0 / currentTotal; for (const k in chances) { chances[k as WeatherFate] = (chances[k as WeatherFate] || 0) * factor; } }
    if (previousWeather && chances[previousWeather] && Math.random() < 0.30) return previousWeather;
    const roll = Math.random(); let cumulativeChance = 0;
    for (const [weather, chance] of Object.entries(chances)) { cumulativeChance += chance || 0; if (roll < cumulativeChance) return weather as WeatherFate; }
    return "normal";
}

// Process growth, health, and weather effects for a single plant
function applyGrowthAndWeather( plant: Plant, slot: GardenSlot, weather: WeatherFate, currentPhase: MoonPhase, currentSeason: Season ): { didGrow: boolean, didWither: boolean, becameMature: boolean, messages: string[] } {
    if (!plant) return { didGrow: false, didWither: false, becameMature: false, messages: [] };
    const plantData = getIngredientData(plant.name); if (!plantData) { console.error(`[TurnEngine] Missing data: ${plant.name}`); return { didGrow: false, didWither: false, becameMature: false, messages: [] }; }
    const result = { didGrow: false, didWither: false, becameMature: false, messages: [] as string[] }; const maxGrowth = plant.maxGrowth ?? plantData.growthTime; plant.maxGrowth = maxGrowth;
    const isRainy = (weather === "rainy" || weather === "stormy"); let currentMoisture = slot.moisture ?? 50; let evaporationRate = 10;
    if (isRainy) { currentMoisture = Math.min(100, currentMoisture + (weather === 'stormy' ? 60 : 40)); evaporationRate = 0; result.messages.push(`Rain watered.`); }
    else if (weather === 'dry') evaporationRate = 25; else if (weather === 'foggy') evaporationRate = 5; else if (weather === 'windy') evaporationRate = 15;
    if (plant.watered) { currentMoisture = Math.min(100, currentMoisture + 40); plant.watered = false; if (!isRainy) result.messages.push(`Watering helped.`); }
    currentMoisture = Math.max(0, currentMoisture - evaporationRate); slot.moisture = currentMoisture;
    const idealMoisture = plantData.idealMoisture; const moistureDiff = Math.abs(currentMoisture - idealMoisture); let healthChange = 0;
    if (moistureDiff < 15) healthChange += 5; else if (moistureDiff > 35) { healthChange -= 15; result.messages.push(`Suffers stress.`); } else if (moistureDiff > 20) healthChange -= 5;
    if (weather === 'stormy' && Math.random() < 0.3) { healthChange -= 25; result.messages.push(`Storm battered!`); } else if (weather === 'dry' && currentMoisture < 20) healthChange -= 10;
    plant.health = Math.min(100, Math.max(0, (plant.health ?? 70) + healthChange));
    plant.deathChance = Math.max(0, Math.min(1, (25 - plant.health) / 25));
    if (plant.health <= 0 || (plant.health < 10 && Math.random() < plant.deathChance * 2) || (plant.health < 25 && Math.random() < plant.deathChance)) { result.didWither = true; result.messages.push(`${plant.name} withered!`); return result; }
    if (!plant.mature && plant.health > 30) {
        const growthCalc = calculateGrowthModifier( plantData, currentSeason, currentPhase, currentMoisture, slot.sunlight ?? 70 );
        let growthIncrease = growthCalc.growthModifier * (plant.health / 100); growthIncrease = Math.max(0.05, growthIncrease);
        plant.growth = (plant.growth ?? 0) + growthIncrease; plant.age = (plant.age ?? 0) + 1; result.didGrow = true;
        if (plant.growth >= maxGrowth) { plant.mature = true; plant.growth = maxGrowth; result.becameMature = true; result.messages.push(`${plant.name} mature!`); }
        result.messages.push(getGrowthStageDescription(plant.name, plant.growth, maxGrowth));
    } else if (!plant.mature && plant.health <= 30) { result.messages.push(`Too unhealthy.`); }
    return result;
}

// Advance the game state by one lunar phase
export function processTurn(state: GameState): GameState {
    const turnEvents: { text: string, category: string, importance: number, player?: string }[] = []; const oldSeason = state.time.season;
    state.time.phase = (state.time.phase + 1) % MoonPhases.length; state.time.phaseName = MoonPhases[state.time.phase]; state.time.dayCount += 1;
    if (state.time.dayCount > 1 && (state.time.dayCount -1) % PHASES_PER_SEASON === 0) { state.time.season = nextSeason(oldSeason); turnEvents.push({ text: `Welcome, ${state.time.season}!`, category: 'season', importance: 5 }); if (state.time.season === "Spring") { state.time.year += 1; turnEvents.push({ text: `Year ${state.time.year} dawns.`, category: 'event', importance: 5 }); } }
    turnEvents.push({ text: `${state.time.phaseName} begins.`, category: 'moon', importance: 3 });
    state.time.previousWeatherFate = state.time.weatherFate; state.time.weatherFate = determineWeather(state.time); turnEvents.push({ text: `Weather: ${state.time.weatherFate}.`, category: 'weather', importance: 3 });
    // Add explicit type for player parameter
    state.players.forEach((player: Player) => {
        // Add explicit type for slot parameter
        player.garden.forEach((slot: GardenSlot) => {
             if (slot.isUnlocked === false) return;
             if (slot.plant) { const plantResult = applyGrowthAndWeather( slot.plant, slot, state.time.weatherFate, state.time.phaseName, state.time.season ); plantResult.messages.forEach(msg => turnEvents.push({ text: `Plot ${slot.id + 1}: ${msg}`, category: 'garden', importance: 2, player: player.id })); if (plantResult.didWither) { slot.plant = null; slot.fertility = Math.max(40, (slot.fertility ?? 70) - 10); turnEvents.push({ text: `Plot ${slot.id + 1} fertility decreased.`, category: 'garden', importance: 1, player: player.id }); } }
             else { slot.fertility = Math.min(90, (slot.fertility ?? 70) + 0.5); let currentMoisture = slot.moisture ?? 50; let evaporationRate = 10; if (state.time.weatherFate === "rainy" || state.time.weatherFate === "stormy") { currentMoisture = Math.min(100, currentMoisture + 30); evaporationRate = 0; } else if (state.time.weatherFate === 'dry') evaporationRate = 25; else if (state.time.weatherFate === 'foggy') evaporationRate = 5; else if (state.time.weatherFate === 'windy') evaporationRate = 15; currentMoisture = Math.max(0, currentMoisture - evaporationRate); slot.moisture = currentMoisture; }
        }); player.daysSurvived = (player.daysSurvived ?? 0) + 1;
    });
    turnEvents.forEach((evt, i) => { const entry: JournalEntry = { id: `j-${state.time.dayCount}-${i}`, turn: state.time.dayCount, date: `${state.time.phaseName}, ${state.time.season} Y${state.time.year}`, text: evt.text, category: evt.category, importance: evt.importance, readByPlayer: false }; state.journal.push(entry); });
    if (state.journal.length > 200) state.journal = state.journal.slice(-150);
    return state;
}